Fictional test archive.
